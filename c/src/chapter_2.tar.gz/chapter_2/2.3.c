#include <stdio.h>

int main(void)
{
	int brothers;
	int brides;
	
	brides = 7;
	brothers = 7;
	printf("%d brides for %d brothers\n", brides, brothers);
	return 0;	
}
