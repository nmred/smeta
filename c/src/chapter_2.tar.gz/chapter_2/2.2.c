#include <stdio.h>

int main(void)
{
	int salary;
	salary = 10000;
	printf("My salary is %d.\n", salary);
	return 0;	
}
