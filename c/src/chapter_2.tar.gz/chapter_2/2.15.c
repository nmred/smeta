#include <stdio.h>

int main(void)
{
	char first = 'T';
	char second = 20;
	
	printf("\nThe first example as a letter looks like this - %c", first);	
	printf("\nThe first example as a letter looks like this - %d", first);	
	printf("\nThe first example as a letter looks like this - %c", second);	
	printf("\nThe first example as a letter looks like this - %d", second);	
}
