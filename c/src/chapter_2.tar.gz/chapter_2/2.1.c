#include <stdio.h>

int main(void)
{
	printf("My salary is $10000\n");
	return 0;	
}
